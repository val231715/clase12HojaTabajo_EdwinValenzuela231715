function salida1(){
    console.log("Mensaje de Bienvenida")
}

function salida2(){
    alert("La suma de los numeros 5 y 3 es "+(5+3))
}

function salida3(){
    let nombre=prompt("Por favor, ingrese su nombre: ")
    alert("Saludos "+nombre);
}

function salida4(){
    let dato=prompt("Por favor, ingrese su nombre: ")
    console.log("El dato ingresado fue: "+dato);
}

function salida5(){
    var fechaActual = new Date();
        alert("La fecha actual es: " + fechaActual);
}

function salida6(){
    document.write("Hola, Mundo");
}