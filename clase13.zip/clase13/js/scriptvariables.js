function salida1(){
    let dato1=prompt("Ingrese dato 1: ")
    let dato2=prompt("Ingrese dato 2: ")
    let dato3=prompt("Ingrese dato 3: ")
    console.log("El dato 1 es: "+dato1 +", El dato 2 es: "+dato2+", El dato 3 es: "+dato3);
}

function salida2(){
    let datopi=3.1416
    alert("DATO PI A CONTINUACION:");
    alert(datopi);
}

function salida3(){
    let num=prompt("Ingrese el dato NUM: ")
    let string=prompt("Ingrese el dato STRING: ")
    alert("Dato NUM= "+num+" Dato STRING= "+string);  
}

function salida4(){
    let num1=prompt("Ingrese el dato NUM1: ")
    let num2=prompt("Ingrese el dato NUM2: ")
    resultado=num1*num2;
    alert("Resultado: "+resultado); 
}

function salida5(){
    let edad=prompt("Ingrese su edad: ")
    alert("Tienes "+edad+" años"); 
}

function salida6(){
    let nombre=prompt("Ingrese su nombre:")
    let apellido=prompt("Ingrese su apellido:")
    alert("Su nombres es: "+nombre+" "+apellido);  
}

